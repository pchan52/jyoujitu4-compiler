/* comment #1 */
int printf ();

/* comment #2 */
int main ()
{
    printf ("hello, world, %d, %d\n", 10, 20);
}
