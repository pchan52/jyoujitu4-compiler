int printf ();
int i;
int j;

int main ()
{
    i = 5;
    j = i;
    printf ("i = %d, j = %d\n", i, j);
}
