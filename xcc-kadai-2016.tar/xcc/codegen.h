/* XCC: Experimental C-subset Compiler.
  Copyright (c) 2002-2008, gondow@cs.titech.ac.jp, All rights reserved.
  $Id: codegen.h,v 1.1 2009/03/13 05:12:54 gondow Exp $ */ 
#ifndef XCC_CODEGEN_MIPS_H
#define XCC_CODEGEN_MIPS_H
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
void codegen (void);
/* ---------------------------------------------------------------------- */
#endif /* XCC_CODEGEN_MIPS_H */
